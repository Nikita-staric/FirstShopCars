﻿using ShopСlothes.Models;

namespace ShopСlothes.Interface
{
    public interface ICarsCategory
    {
        IEnumerable<Category> AllCategory { get;}//получаем данные
    }
}
